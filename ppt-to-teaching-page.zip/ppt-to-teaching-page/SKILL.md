---
name: ppt-to-teaching-page
description: 将 PPT 文件转化为增强版教学网页和 Markdown 文档。用户上传 .pptx 文件后，自动提取幻灯片的文字内容和图片，结合图片视觉内容理解每页 PPT，为每一页补充"引入与背景（动机）"、"直觉理解"、"具体例子"、"拓展延伸"四个板块，输出一个可一键展开查看的美观 HTML 教学网页（图片可点击放大）和配套 Markdown 文件。触发条件：用户发送 pptx 文件、提到"生成教学页面"、"优化 PPT"、"把 PPT 变成网页"等。
---

# ppt-to-teaching-page

将 PPT 的"结论堆砌"风格转化为"有推导、有理解、有例子"的教学文档，支持图片识别与原图展示。

## 工作流程

### Step 1 — 提取 PPT 内容（含图片）

```bash
python3 <skill_dir>/scripts/extract_pptx.py <file.pptx> > raw.json
```

输出 JSON 中，每张幻灯片包含：
```json
{
  "index": 1,
  "title": "幻灯片标题",
  "bullets": ["要点1", "要点2"],
  "notes": "备注",
  "images": [
    { "order": 0, "data_uri": "data:image/png;base64,..." }
  ]
}
```

`images` 按视觉阅读顺序排列（从上到下、从左到右）。小于 50×50px 的装饰性图标已自动过滤。

### Step 2 — AI 内容增强（含图片理解）

读取 `raw.json`，对每张幻灯片完成以下操作，生成 `enriched.json`：

#### 2a. 理解图片内容

如果某张幻灯片的 `images` 非空，需**直接查看这些 base64 图片**（在 raw.json 中已内嵌），理解其内容（图表、公式截图、示意图、坐标轴等），并将理解结果写入 `image_descriptions` 字段：

```json
"image_descriptions": [
  "这是一张展示梯度下降过程的等高线图，箭头指向损失函数的极小值点"
]
```

`image_descriptions` 与 `images` 数组**一一对应**，描述应简洁（1-2 句），但要点明图的核心内容。若图片是纯装饰性的（背景图、logo），写空字符串 `""` 跳过即可。

#### 2b. 生成四个增强字段

结合文字（bullets）和图片内容（image_descriptions）一起理解当前幻灯片，写出：

| 字段 | 含义 | 写法指导 |
|---|---|---|
| `motivation` | 引入与背景 | 这个概念/公式/结论是为了解决什么问题？从哪里推导出来的？补充铺垫过程。 |
| `intuition` | 直觉理解 | 用最简单的语言说清楚核心本质。公式/图表背后的直觉是什么？ |
| `example` | 具体例子 | 最小化、最直观的具体例子（数字、场景、类比），验证或说明结论。 |
| `extension` | 拓展延伸 | 相关概念、进阶应用、延伸阅读（1-3 条，不要过长）。 |

**约定：**
- 封面/目录页（bullets 极少且无实质内容的图）：四个字段均写 `""`。
- 数学公式用 LaTeX：行内 `$...$`，独立行 `$$...$$`（HTML 支持 KaTeX 渲染）。
- 语言跟随 PPT 原始语言（中文 PPT → 中文增强）。
- 每个字段 3-8 句，简洁有力。
- **图片理解要融入增强内容**：如果图片展示了某个算法过程，intuition 里应结合图中的视觉信息来解释，而不是只看文字。

enriched.json 示例（含图片）：
```json
{
  "title": "机器学习基础",
  "slides": [
    {
      "index": 3,
      "title": "梯度下降",
      "bullets": ["更新规则：θ := θ - α∇J(θ)", "α 为学习率"],
      "notes": "",
      "images": [{ "order": 0, "data_uri": "data:image/png;base64,..." }],
      "image_descriptions": ["等高线图展示损失函数 J(θ) 的曲面，箭头沿负梯度方向逐步走向最低点"],
      "motivation": "参数初始化后我们需要找一个方向让损失下降，梯度给出了当前最陡上升方向，取负即最速下降方向...",
      "intuition": "想象在山上闭着眼睛下山：每一步都沿脚下最陡的坡面往下走，α 控制步长大小。图中箭头就是这个过程的可视化。",
      "example": "设 $J(\\theta) = \\theta^2$，梯度为 $2\\theta$，从 $\\theta_0=3$ 出发，学习率 $\\alpha=0.1$：第一步 $\\theta_1 = 3 - 0.1\\times6 = 2.4$，逐步逼近最小值 0。",
      "extension": "- 变体：SGD（随机梯度下降）、Mini-batch GD、Adam 自适应学习率。\n- 学习率过大会震荡，过小收敛慢——学习率调度是重要工程技巧。"
    }
  ]
}
```

### Step 3 — 生成输出文件

```bash
python3 <skill_dir>/scripts/build_teaching_page.py \
    enriched.json \
    <skill_dir>/assets/teaching-template.html \
    <output_stem>
```

生成：
- `<output_stem>.html` — 教学网页，原图直接内嵌，**点击图片可全屏放大（Lightbox）**，点击标题折叠/展开各节
- `<output_stem>.md`   — Markdown 版本，图片以 base64 内嵌（支持 Obsidian、语雀等）

### Step 4 — 交付给用户

发送生成的 `.html` 和 `.md` 文件，简要说明：
- 网页默认展开第一节，点击任意章节标题可展开/折叠
- 点击图片可全屏预览，按 Esc 或点击背景关闭
- 数学公式渲染需联网（KaTeX CDN）

## 路径约定

- 临时文件（raw.json、enriched.json）写入工作区根目录，完成后可清理。
- `<skill_dir>` = `~/.openclaw/skills/ppt-to-teaching-page/`
- 输出文件名默认为 `<pptx文件名不含扩展名>_teaching`，如 `lecture03_teaching.html`

## 注意事项

- PPT 超过 30 页时，按章节分批增强，每批不超过 15 页，避免单次 token 过多。
- 如果某张图片是公式截图（文字渲染为图片），在 intuition/example 中直接引用并转写为 LaTeX，不要忽略。
- raw.json 中 `images[].data_uri` 字段较大（base64），处理时无需打印到终端，直接传入增强流程即可。
