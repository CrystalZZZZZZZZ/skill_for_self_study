#!/usr/bin/env python3
"""
build_teaching_page.py

Given an enriched JSON file, produce:
  - <stem>.html  (standalone teaching page with inline images)
  - <stem>.md    (Markdown version with base64 images)

Input JSON schema (per slide):
  {
    "index": 1,
    "title": "...",
    "bullets": ["..."],
    "notes": "...",
    "images": [{"order": 0, "data_uri": "data:image/png;base64,..."}],
    "image_descriptions": ["AI description of image 0", ...],  // optional, parallel to images
    "motivation": "...",
    "intuition": "...",
    "example": "...",
    "extension": "..."
  }

Usage:
    python3 build_teaching_page.py enriched.json <template.html> [output_stem]
"""

import sys
import json
import html as html_mod
import re


# ── helpers ───────────────────────────────────────────────────────────────────

def esc(s):
    return html_mod.escape(str(s))


def text_to_html_paras(text: str) -> str:
    if not text:
        return ""
    lines = [l.rstrip() for l in text.strip().splitlines()]
    bullet_pat = re.compile(r'^[-•*]\s+(.+)')
    parts = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line:
            i += 1
            continue
        m = bullet_pat.match(line)
        if m:
            items = []
            while i < len(lines):
                bm = bullet_pat.match(lines[i])
                if bm:
                    items.append(f"<li>{esc(bm.group(1))}</li>")
                    i += 1
                elif not lines[i]:
                    i += 1
                    break
                else:
                    break
            parts.append("<ul>" + "".join(items) + "</ul>")
        else:
            parts.append(f"<p>{esc(line)}</p>")
            i += 1
    return "\n".join(parts)


def bullets_to_html(bullets):
    if not bullets:
        return ""
    items = "".join(f"<li>{esc(b)}</li>" for b in bullets)
    return f"<ul>{items}</ul>"


def images_to_html(images, descriptions=None):
    """Render images as <figure> blocks with optional AI-generated captions."""
    if not images:
        return ""
    parts = []
    for i, img in enumerate(images):
        data_uri = img.get("data_uri", "")
        if not data_uri:
            continue
        caption = ""
        if descriptions and i < len(descriptions) and descriptions[i]:
            caption = f"<figcaption>{esc(descriptions[i])}</figcaption>"
        parts.append(
            f'<figure class="slide-image">'
            f'<img src="{data_uri}" alt="幻灯片图片 {i+1}" loading="lazy" />'
            f'{caption}'
            f'</figure>'
        )
    return "\n".join(parts)


BLOCK_META = {
    "original":   ("📋", "原始内容"),
    "motivation": ("💡", "引入与背景"),
    "intuition":  ("🔍", "直觉理解"),
    "example":    ("✏️",  "具体例子"),
    "extension":  ("🔗", "拓展延伸"),
}


def make_block(kind: str, content_html: str) -> str:
    if not content_html or not content_html.strip():
        return ""
    icon, label = BLOCK_META[kind]
    return f"""
    <div class="block block-{kind}">
      <div class="block-label">{icon} {label}</div>
      {content_html}
    </div>"""


def make_section(slide: dict) -> str:
    idx   = slide["index"]
    title = slide.get("title", f"Slide {idx}")
    sid   = f"slide-{idx}"

    bullets      = slide.get("bullets", [])
    images       = slide.get("images", [])
    descriptions = slide.get("image_descriptions", [])

    bullets_html  = bullets_to_html(bullets)
    images_html   = images_to_html(images, descriptions)

    # Original block: text bullets + inline images
    original_inner = ""
    if bullets_html:
        original_inner += bullets_html
    if images_html:
        original_inner += f'\n<div class="slide-images">{images_html}</div>'
    if not original_inner:
        original_inner = "<p><em>（无文字内容）</em></p>"

    blocks = make_block("original", original_inner)
    blocks += make_block("motivation", text_to_html_paras(slide.get("motivation", "")))
    blocks += make_block("intuition",  text_to_html_paras(slide.get("intuition", "")))
    blocks += make_block("example",    text_to_html_paras(slide.get("example", "")))
    blocks += make_block("extension",  text_to_html_paras(slide.get("extension", "")))

    return f"""
  <div class="section-card" id="{sid}">
    <div class="section-header">
      <div class="slide-num">{idx}</div>
      <h2>{esc(title)}</h2>
      <svg class="chevron" viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg>
    </div>
    <div class="section-body">
      {blocks}
    </div>
  </div>"""


def make_toc_item(slide: dict) -> str:
    idx   = slide["index"]
    title = slide.get("title", f"Slide {idx}")
    return f'<li><a href="#slide-{idx}">{esc(title)}</a></li>'


# ── Markdown builder ──────────────────────────────────────────────────────────

def slide_to_md(slide: dict) -> str:
    idx   = slide["index"]
    title = slide.get("title", f"Slide {idx}")
    parts = [f"## {idx}. {title}\n"]

    bullets = slide.get("bullets", [])
    images  = slide.get("images", [])
    descriptions = slide.get("image_descriptions", [])

    if bullets or images:
        parts.append("### 原始内容\n")
        parts.extend(f"- {b}" for b in bullets)
        # Embed images as base64 in Markdown (works in Obsidian, Notion, etc.)
        for i, img in enumerate(images):
            data_uri = img.get("data_uri", "")
            if data_uri:
                cap = descriptions[i] if descriptions and i < len(descriptions) else f"图片 {i+1}"
                parts.append(f"\n![{cap}]({data_uri})\n")
        parts.append("")

    for key, label in [("motivation", "💡 引入与背景"),
                        ("intuition",  "🔍 直觉理解"),
                        ("example",    "✏️ 具体例子"),
                        ("extension",  "🔗 拓展延伸")]:
        val = slide.get(key, "").strip()
        if val:
            parts.append(f"### {label}\n")
            parts.append(val)
            parts.append("")

    return "\n".join(parts)


# ── main ──────────────────────────────────────────────────────────────────────

def build(enriched_path: str, template_path: str, output_stem: str = "teaching_output"):
    with open(enriched_path, encoding="utf-8") as f:
        data = json.load(f)
    with open(template_path, encoding="utf-8") as f:
        template = f.read()

    title  = data.get("title", "Teaching Page")
    slides = data.get("slides", [])

    toc_html      = "\n    ".join(make_toc_item(s) for s in slides)
    sections_html = "\n".join(make_section(s) for s in slides)

    html_out = (template
                .replace("{{TITLE}}", esc(title))
                .replace("{{TOC_ITEMS}}", toc_html)
                .replace("{{SECTIONS}}", sections_html))

    md_lines = [f"# {title}\n"]
    for slide in slides:
        md_lines.append(slide_to_md(slide))
    md_out = "\n".join(md_lines)

    html_file = f"{output_stem}.html"
    md_file   = f"{output_stem}.md"

    with open(html_file, "w", encoding="utf-8") as f:
        f.write(html_out)
    with open(md_file, "w", encoding="utf-8") as f:
        f.write(md_out)

    print(f"✅ HTML → {html_file}")
    print(f"✅ MD   → {md_file}")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: build_teaching_page.py <enriched.json> <template.html> [output_stem]")
        sys.exit(1)
    stem = sys.argv[3] if len(sys.argv) > 3 else "teaching_output"
    build(sys.argv[1], sys.argv[2], stem)
