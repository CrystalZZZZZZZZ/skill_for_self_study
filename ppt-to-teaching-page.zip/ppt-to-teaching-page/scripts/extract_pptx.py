#!/usr/bin/env python3
"""
extract_pptx.py - Extract structured content (text + images) from a .pptx file.

Usage:
    python3 extract_pptx.py <file.pptx>

Output (JSON to stdout):
    {
      "title": "Presentation title",
      "slides": [
        {
          "index": 1,
          "title": "slide title",
          "bullets": ["bullet text", ...],
          "notes": "speaker notes if any",
          "images": [
            {
              "order": 0,           // visual order on slide (top-to-bottom, left-to-right)
              "data_uri": "data:image/png;base64,..."
            },
            ...
          ]
        },
        ...
      ]
    }

Notes:
- Images are extracted as base64-encoded data URIs (PNG for non-JPEG, JPEG for JPEG).
- Images smaller than 50x50 px (likely decorative icons) are skipped.
- The 'images' list preserves visual order so the AI can correlate images with text.
"""

import sys
import json
import base64
import io
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE
from pptx.util import Emu


def extract_text_from_shape(shape):
    texts = []
    if shape.has_text_frame:
        for para in shape.text_frame.paragraphs:
            line = para.text.strip()
            if line:
                texts.append(line)
    return texts


def is_title_placeholder(shape):
    from pptx.enum.shapes import PP_PLACEHOLDER
    if shape.is_placeholder:
        ph_type = shape.placeholder_format.type
        return ph_type in (
            PP_PLACEHOLDER.TITLE,
            PP_PLACEHOLDER.CENTER_TITLE,
            PP_PLACEHOLDER.SUBTITLE,
        )
    return False


def shape_top_left_key(shape):
    """Sort key: top → left (for visual reading order)."""
    try:
        return (int(shape.top or 0), int(shape.left or 0))
    except Exception:
        return (0, 0)


def get_image_data_uri(image):
    """Return a data URI for a pptx Image object. Returns None on failure."""
    try:
        blob = image.blob
        ct = image.content_type  # e.g. 'image/png', 'image/jpeg'
        if ct not in ("image/png", "image/jpeg", "image/jpg",
                      "image/gif", "image/webp", "image/bmp"):
            # Convert unknown to PNG via PIL if available
            try:
                from PIL import Image as PILImage
                img = PILImage.open(io.BytesIO(blob)).convert("RGBA")
                buf = io.BytesIO()
                img.save(buf, format="PNG")
                blob = buf.getvalue()
                ct = "image/png"
            except ImportError:
                ct = "image/png"  # hope for the best
        mime = ct if ct != "image/jpg" else "image/jpeg"
        b64 = base64.b64encode(blob).decode("ascii")
        return f"data:{mime};base64,{b64}"
    except Exception:
        return None


def is_too_small(shape, min_px=50):
    """Skip shapes whose bounding box is smaller than min_px in either dimension."""
    try:
        # EMU → pixels at 96 dpi: 1 inch = 914400 EMU, 1 inch = 96 px
        w_px = int(shape.width  / 914400 * 96)
        h_px = int(shape.height / 914400 * 96)
        return w_px < min_px or h_px < min_px
    except Exception:
        return False


def extract_images_from_slide(slide):
    """Return list of {order, data_uri} dicts for all images on the slide."""
    image_shapes = []
    for shape in slide.shapes:
        # Direct picture shape
        if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
            image_shapes.append(shape)
        # Placeholder containing an image
        elif shape.is_placeholder and hasattr(shape, "image"):
            image_shapes.append(shape)

    # Sort by visual order
    image_shapes.sort(key=shape_top_left_key)

    results = []
    for order, shape in enumerate(image_shapes):
        if is_too_small(shape):
            continue
        try:
            img = shape.image
        except AttributeError:
            continue
        data_uri = get_image_data_uri(img)
        if data_uri:
            results.append({"order": order, "data_uri": data_uri})

    return results


def extract_pptx(path):
    prs = Presentation(path)
    slides_data = []
    presentation_title = None

    for idx, slide in enumerate(prs.slides, start=1):
        slide_title = None
        content_bullets = []
        notes_text = ""

        if slide.has_notes_slide:
            notes_tf = slide.notes_slide.notes_text_frame
            notes_text = notes_tf.text.strip() if notes_tf else ""

        # Sort shapes by visual order before extracting text
        sorted_shapes = sorted(slide.shapes, key=shape_top_left_key)

        for shape in sorted_shapes:
            if is_title_placeholder(shape):
                slide_title = shape.text.strip()
            else:
                texts = extract_text_from_shape(shape)
                content_bullets.extend(texts)

        if slide_title:
            content_bullets = [b for b in content_bullets if b != slide_title]

        if idx == 1 and slide_title:
            presentation_title = slide_title

        images = extract_images_from_slide(slide)

        slides_data.append({
            "index": idx,
            "title": slide_title or f"Slide {idx}",
            "bullets": content_bullets,
            "notes": notes_text,
            "images": images,
        })

    return {
        "title": presentation_title or "Presentation",
        "slides": slides_data,
    }


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: extract_pptx.py <file.pptx>", file=sys.stderr)
        sys.exit(1)
    result = extract_pptx(sys.argv[1])
    print(json.dumps(result, ensure_ascii=False, indent=2))
